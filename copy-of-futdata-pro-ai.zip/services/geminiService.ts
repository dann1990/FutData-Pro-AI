
import { GoogleGenAI } from "@google/genai";
import { AnalysisResult, DailyInsight } from "../types";

// Initialize the client
// NOTE: API Key must be set in process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
**ROLE:** You are "FutData Pro AI", a senior football data analyst and expert in statistical modeling for sports betting. Your function is not to guess, but to calculate probabilities based on mathematical data (Poisson Distribution, xG - Expected Goals, and Power Ranking).

**OBJECTIVE:** Provide high-reliability football forecasts, minimizing risks and focusing on expected value (EV+).

**METHODOLOGY:**
1. Analyze Recent Form (Last 5 games).
2. Analyze H2H (Head-to-Head) - specific scores.
3. Compare Attack vs Defense.
4. Check for Critical Absences/Injuries (using Search).
5. Evaluate Motivation.

**OUTPUT:**
You must return a strictly valid JSON object inside a markdown code block.
The JSON must match this structure:
{
  "match_info": { "home": "String", "away": "String", "date": "String", "time": "String", "league": "String" },
  "h2h_history": [
    { "date": "String (Year/Date)", "home_team": "String", "away_team": "String", "score": "String (e.g. 2-1)" }
  ],
  "stats": {
    "home_stats": { "attack": Number(0-10), "defense": Number(0-10) },
    "away_stats": { "attack": Number(0-10), "defense": Number(0-10) },
    "probabilities": { "home": Number(0-100), "draw": Number(0-100), "away": Number(0-100) },
    "xg_total": Number
  },
  "predictions": {
    "winner": { "selection": "String", "risk": "Low/Medium/High (or Baixo/Médio/Alto)" },
    "goals": { "selection": "String", "probability": "String%" },
    "home_total": "String",
    "away_total": "String"
  },
  "verdict": {
    "safest_bet": "String",
    "risk_level": Number(0-10),
    "justification": "String (max 2 lines)"
  },
  "accumulator": {
    "suggestion": "String (Suggest a Double or Treble with other games on this date)",
    "odds_range": "String (e.g., 1.80 - 2.50)"
  }
}

IMPORTANT: If the user requests a specific language, translate all String values (selection, risk, verdict, justification, suggestion) to that language.
`;

// Helper to clean JSON output
const parseGeminiJSON = <T>(text: string): T => {
  const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/) || text.match(/```\n([\s\S]*?)\n```/);
  const jsonString = jsonMatch ? jsonMatch[1] : text;
  
  try {
    return JSON.parse(jsonString) as T;
  } catch (e) {
    const start = jsonString.indexOf('{');
    const end = jsonString.lastIndexOf('}');
    if (start !== -1 && end !== -1) {
      return JSON.parse(jsonString.substring(start, end + 1)) as T;
    }
    throw e;
  }
};

export const analyzeMatch = async (
  home: string,
  away: string,
  date: string,
  league: string,
  lang: 'en' | 'pt' = 'en'
): Promise<AnalysisResult> => {
  const languageName = lang === 'pt' ? 'Portuguese (Brazil)' : 'English';
  
  const prompt = `
  Analyze the following football match:
  Home: ${home}
  Away: ${away}
  Date: ${date || "Upcoming"}
  League: ${league || "Any"}
  
  OUTPUT LANGUAGE: ${languageName}
  (Ensure all text fields in the JSON are in ${languageName})

  Step 1: Use Google Search to find the latest standings, last 5 match results for both teams, head-to-head history (last 3-5 meetings), and significant injury news. 
  Step 2: IMPORTANT: Find the specific Kick-off Time for this match.
  Step 3: Calculate Poisson probabilities and ratings based on this data.
  Step 4: Output the JSON result including specific H2H scores.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.3, 
        tools: [{ googleSearch: {} }],
      },
    });

    if (!response.text) throw new Error("No response from AI");
    return parseGeminiJSON<AnalysisResult>(response.text);

  } catch (error) {
    console.error("Analysis failed:", error);
    throw new Error(lang === 'pt' ? "Falha ao analisar a partida. Tente novamente." : "Failed to analyze match. Please try again.");
  }
};

export const fetchDailyInsights = async (lang: 'en' | 'pt' = 'en'): Promise<DailyInsight> => {
  const now = new Date();
  const today = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const currentTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  
  const languageName = lang === 'pt' ? 'Portuguese (Brazil)' : 'English';

  const prompt = `
  CONTEXT:
  - Today's Date: ${today}
  - User's Current Time: ${currentTime}
  - User's Timezone: ${userTimezone}
  - Output Language: ${languageName}

  TASK:
  1. Search for the schedule of major football leagues (Premier League, La Liga, Serie A, Bundesliga, Champions League, Brasileirão, Libertadores, etc) happening TODAY.
  2. FILTER STRICTLY: Only select matches that have NOT started yet (Kick-off time must be AFTER ${currentTime}). Exclude live or finished games.
  3. Select the top 3-5 most important UPCOMING matches.
  4. Based on these UPCOMING matchups, create a "Smart Accumulator" (Multiple Bet) with 2 or 3 safe selections.

  Return a JSON object:
  {
    "date": "${today}",
    "matches": [
      { "home": "Team A", "away": "Team B", "time": "HH:MM", "league": "League Name" }
    ],
    "accumulator": {
      "title": "String (e.g. Daily Double / Múltipla do Dia)",
      "games": ["String - Game 1: Prediction", "String - Game 2: Prediction"],
      "total_odds": "String (e.g. 2.10)",
      "reasoning": "String (Brief explanation)"
    }
  }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        temperature: 0.4,
        tools: [{ googleSearch: {} }],
      },
    });

    if (!response.text) throw new Error("No response from AI");
    return parseGeminiJSON<DailyInsight>(response.text);

  } catch (error) {
    console.error("Daily Insight failed:", error);
    throw error;
  }
};
