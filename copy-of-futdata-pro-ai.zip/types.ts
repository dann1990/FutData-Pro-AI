
export interface ProbabilityDistribution {
  home: number;
  draw: number;
  away: number;
}

export interface TeamStats {
  attack: number; // 0-10
  defense: number; // 0-10
}

export interface PredictionMarket {
  selection: string;
  risk?: string;
  probability?: string;
}

export interface H2HMatch {
  date: string;
  home_team: string;
  away_team: string;
  score: string;
}

export interface AnalysisResult {
  match_info: {
    home: string;
    away: string;
    date: string;
    time: string;
    league: string;
  };
  h2h_history: H2HMatch[];
  stats: {
    home_stats: TeamStats;
    away_stats: TeamStats;
    probabilities: ProbabilityDistribution;
    xg_total: number;
  };
  predictions: {
    winner: PredictionMarket;
    goals: PredictionMarket;
    home_total: string;
    away_total: string;
  };
  verdict: {
    safest_bet: string;
    risk_level: number; // 0-10
    justification: string;
  };
  accumulator: {
    suggestion: string;
    odds_range: string;
  };
}

export interface DailyInsight {
  date: string;
  matches: {
    home: string;
    away: string;
    time: string;
    league: string;
  }[];
  accumulator: {
    title: string;
    games: string[]; // e.g. "Arsenal to win", "Real Madrid Over 1.5"
    total_odds: string;
    reasoning: string;
  };
}

export interface FormState {
  homeTeam: string;
  awayTeam: string;
  date: string;
  league: string;
}
