
import React, { useState, useEffect, useCallback } from 'react';
import { BrainCircuit, Search, RotateCcw, Loader2, Languages, Sparkles } from 'lucide-react';
import { analyzeMatch, fetchDailyInsights } from './services/geminiService';
import { AnalysisResult as AnalysisType, FormState, DailyInsight } from './types';
import AnalysisResult from './components/AnalysisResult';
import DailyInsightCard from './components/DailyInsight';

const TEXT = {
  en: {
    subtitle: "Powered by Gemini Models",
    newAnalysis: "New Analysis",
    heroTitle: "Predict matches with",
    heroSubtitle: "Precision Analytics",
    heroDesc: "Harness the power of Gemini 2.5 Flash, Poisson distributions, and real-time data grounding to uncover EV+ betting opportunities.",
    labelHome: "Home Team",
    labelAway: "Away Team",
    labelDate: "Date",
    labelLeague: "League (Optional)",
    btnAnalyze: "Generate Forecast",
    btnLoading: "Analyzing Statistics...",
    loadingText: "Searching live data & calculating probabilities...",
    placeholderTeam: "e.g. Arsenal",
    placeholderLeague: "e.g. Premier League",
    errorTitle: "Error",
    errorGeneric: "An unexpected error occurred."
  },
  pt: {
    subtitle: "Desenvolvido com Gemini",
    newAnalysis: "Nova Análise",
    heroTitle: "Preveja jogos com",
    heroSubtitle: "Precisão Analítica",
    heroDesc: "Utilize o poder do Gemini 2.5 Flash, distribuição de Poisson e dados em tempo real para descobrir apostas de valor esperado (EV+).",
    labelHome: "Time da Casa",
    labelAway: "Time Visitante",
    labelDate: "Data",
    labelLeague: "Liga (Opcional)",
    btnAnalyze: "Gerar Prognóstico",
    btnLoading: "Analisando Estatísticas...",
    loadingText: "Buscando dados ao vivo e calculando probabilidades...",
    placeholderTeam: "ex: Flamengo",
    placeholderLeague: "ex: Brasileirão",
    errorTitle: "Erro",
    errorGeneric: "Ocorreu um erro inesperado."
  }
};

const App: React.FC = () => {
  const [lang, setLang] = useState<'en' | 'pt'>('pt');
  const [form, setForm] = useState<FormState>({
    homeTeam: '',
    awayTeam: '',
    date: new Date().toISOString().split('T')[0],
    league: ''
  });

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisType | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Daily Insight State
  const [dailyInsight, setDailyInsight] = useState<DailyInsight | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [showInsight, setShowInsight] = useState(true);

  const t = TEXT[lang];

  // Define loadInsights with useCallback to allow manual refresh and interval calling
  const loadInsights = useCallback(async () => {
    setLoadingInsight(true);
    try {
      const data = await fetchDailyInsights(lang);
      setDailyInsight(data);
      setShowInsight(true);
    } catch (e) {
      console.log("Could not fetch daily insights", e);
    } finally {
      setLoadingInsight(false);
    }
  }, [lang]);

  // Fetch daily insights on mount, on lang change, and every 24 hours
  useEffect(() => {
    loadInsights();

    // Set up a 24-hour interval refresh
    const intervalId = setInterval(() => {
      loadInsights();
    }, 24 * 60 * 60 * 1000); // 24 hours in milliseconds

    return () => clearInterval(intervalId);
  }, [loadInsights]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.homeTeam || !form.awayTeam) return;

    setLoading(true);
    setError(null);
    setResult(null);
    setShowInsight(false); // Hide insight when analysis starts

    try {
      const data = await analyzeMatch(form.homeTeam, form.awayTeam, form.date, form.league, lang);
      setResult(data);
    } catch (err: any) {
      setError(err.message || t.errorGeneric);
    } finally {
      setLoading(false);
    }
  };

  const toggleLang = () => {
    setLang(prev => prev === 'en' ? 'pt' : 'en');
  };

  const handleSelectMatchFromInsight = (home: string, away: string, league: string) => {
     setForm({
         homeTeam: home,
         awayTeam: away,
         date: new Date().toISOString().split('T')[0],
         league: league
     });
     window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-50 selection:bg-emerald-500/30 selection:text-emerald-200 pb-12">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-emerald-400 cursor-pointer" onClick={() => {setResult(null); setShowInsight(true);}}>
            <BrainCircuit className="w-8 h-8" />
            <div>
              <h1 className="text-xl font-bold leading-none text-white tracking-tight">FutData <span className="text-emerald-400">Pro AI</span></h1>
              <p className="text-[10px] text-slate-400 font-mono tracking-wider uppercase">{t.subtitle}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={toggleLang}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800 text-slate-300 hover:text-white border border-slate-700 hover:border-slate-600 rounded-lg transition-colors"
            >
              <Languages size={14} />
              {lang === 'en' ? 'EN' : 'PT'}
            </button>

            {result && !loading && (
               <button 
                 onClick={() => { setResult(null); setForm(prev => ({...prev, homeTeam: '', awayTeam: ''})); setShowInsight(true); }}
                 className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
               >
                  <RotateCcw size={14} /> {t.newAnalysis}
               </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 pt-8">
        
        {/* Daily Insight Loading / Display */}
        {!result && loadingInsight && !dailyInsight && (
            <div className="max-w-4xl mx-auto mb-8 p-4 border border-slate-800 rounded-xl bg-slate-800/30 flex items-center justify-center gap-3 text-slate-500 animate-pulse">
                <Sparkles size={18} />
                <span className="text-sm font-medium">Loading Today's Top Matches...</span>
            </div>
        )}
        
        {!result && dailyInsight && showInsight && (
            <DailyInsightCard 
                data={dailyInsight} 
                lang={lang} 
                loading={loadingInsight}
                onRefresh={loadInsights}
                onClose={() => setShowInsight(false)}
                onSelectMatch={handleSelectMatchFromInsight}
            />
        )}

        {/* Intro / Form Section */}
        {!result && (
            <div className="max-w-xl mx-auto mt-4 text-center space-y-8 animate-fade-in-up">
                <div className="space-y-2">
                    <h2 className="text-3xl md:text-4xl font-bold text-white">
                        {t.heroTitle} <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">{t.heroSubtitle}</span>
                    </h2>
                    <p className="text-slate-400 text-sm md:text-base">
                        {t.heroDesc}
                    </p>
                </div>

                <form onSubmit={handleAnalyze} className="bg-slate-800/50 border border-slate-700 p-6 rounded-2xl shadow-2xl shadow-black/20 space-y-4 text-left">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs font-medium text-slate-400 ml-1">{t.labelHome}</label>
                            <input 
                                name="homeTeam"
                                value={form.homeTeam}
                                onChange={handleChange}
                                placeholder={t.placeholderTeam}
                                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
                                required
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs font-medium text-slate-400 ml-1">{t.labelAway}</label>
                            <input 
                                name="awayTeam"
                                value={form.awayTeam}
                                onChange={handleChange}
                                placeholder={t.placeholderTeam}
                                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
                                required
                            />
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs font-medium text-slate-400 ml-1">{t.labelDate}</label>
                            <input 
                                type="date"
                                name="date"
                                value={form.date}
                                onChange={handleChange}
                                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all [color-scheme:dark]"
                            />
                        </div>
                         <div className="space-y-1">
                            <label className="text-xs font-medium text-slate-400 ml-1">{t.labelLeague}</label>
                            <input 
                                name="league"
                                value={form.league}
                                onChange={handleChange}
                                placeholder={t.placeholderLeague}
                                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
                            />
                        </div>
                    </div>

                    <button 
                        type="submit" 
                        disabled={loading}
                        className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3.5 rounded-lg transition-all transform hover:scale-[1.02] active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed flex justify-center items-center gap-2 shadow-lg shadow-emerald-900/20"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="animate-spin" size={20} />
                                {t.btnLoading}
                            </>
                        ) : (
                            <>
                                <Search size={20} />
                                {t.btnAnalyze}
                            </>
                        )}
                    </button>
                </form>
                
                {error && (
                    <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-lg text-sm">
                        {error}
                    </div>
                )}
            </div>
        )}

        {/* Result Section */}
        {loading && result === null && (
           <div className="mt-16 flex flex-col items-center justify-center space-y-4 text-slate-500 animate-pulse">
              <div className="relative">
                  <div className="w-16 h-16 border-4 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin"></div>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                      <BrainCircuit className="w-6 h-6 text-emerald-500" />
                  </div>
              </div>
              <p className="font-mono text-sm">{t.loadingText}</p>
           </div>
        )}

        {result && !loading && (
            <AnalysisResult data={result} lang={lang} />
        )}

      </main>
    </div>
  );
};

export default App;
