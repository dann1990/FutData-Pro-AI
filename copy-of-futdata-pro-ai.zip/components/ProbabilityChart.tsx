import React from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { ProbabilityDistribution } from '../types';

interface Props {
  probabilities: ProbabilityDistribution;
  lang: 'en' | 'pt';
}

const ProbabilityChart: React.FC<Props> = ({ probabilities, lang }) => {
  const labels = {
    en: { home: 'Home Win', draw: 'Draw', away: 'Away Win', title: 'Poisson Probabilities' },
    pt: { home: 'Vitória Casa', draw: 'Empate', away: 'Vitória Fora', title: 'Probabilidades Poisson' }
  };

  const t = labels[lang];

  const data = [
    { name: t.home, value: probabilities.home, color: '#10b981' }, // Emerald 500
    { name: t.draw, value: probabilities.draw, color: '#94a3b8' }, // Slate 400
    { name: t.away, value: probabilities.away, color: '#ef4444' }, // Red 500
  ];

  return (
    <div className="w-full h-64 bg-slate-800 rounded-xl p-4 border border-slate-700 shadow-sm">
      <h3 className="text-sm font-semibold text-slate-300 mb-2 text-center uppercase tracking-wider">{t.title}</h3>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9' }}
            itemStyle={{ color: '#f1f5f9' }}
            formatter={(value: number) => [`${value}%`, 'Prob']}
          />
          <Legend verticalAlign="bottom" height={36} iconType="circle" />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ProbabilityChart;