
import React from 'react';
import { DailyInsight } from '../types';
import { CalendarDays, Trophy, Lightbulb, X, ArrowRight, RefreshCw } from 'lucide-react';

interface Props {
  data: DailyInsight;
  lang: 'en' | 'pt';
  loading: boolean;
  onRefresh: () => void;
  onClose: () => void;
  onSelectMatch: (home: string, away: string, league: string) => void;
}

const LABELS = {
  en: {
    todayMatches: "Today's Matches",
    dailyTip: "Smart Accumulator",
    analyze: "Analyze",
    refresh: "Refresh Data"
  },
  pt: {
    todayMatches: "Jogos de Hoje",
    dailyTip: "Múltipla do Dia",
    analyze: "Analisar",
    refresh: "Atualizar Dados"
  }
};

const DailyInsightCard: React.FC<Props> = ({ data, lang, loading, onRefresh, onClose, onSelectMatch }) => {
  const t = LABELS[lang];

  return (
    <div className="w-full max-w-4xl mx-auto mb-8 animate-fade-in-down relative">
      <div className="bg-slate-800/80 backdrop-blur-sm border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-900 to-slate-900 px-4 py-3 flex justify-between items-center border-b border-slate-700">
          <div className="flex items-center gap-2 text-indigo-300">
            <CalendarDays size={18} />
            <span className="text-sm font-semibold uppercase tracking-wider">{data.date}</span>
          </div>
          <div className="flex items-center gap-2">
             <button 
                onClick={onRefresh} 
                disabled={loading}
                title={t.refresh}
                className={`text-slate-400 hover:text-white transition-colors p-1 rounded-md hover:bg-slate-700/50 ${loading ? 'animate-spin' : ''}`}
             >
                <RefreshCw size={16} />
             </button>
             <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors p-1 rounded-md hover:bg-slate-700/50">
                <X size={18} />
             </button>
          </div>
        </div>

        <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Match List */}
          <div className="md:col-span-2 space-y-3">
            <h3 className="text-sm font-bold text-slate-300 mb-3 flex items-center gap-2">
              <Trophy size={16} className="text-yellow-500" />
              {t.todayMatches}
            </h3>
            <div className="space-y-2">
              {data.matches.map((match, idx) => (
                <div 
                  key={idx} 
                  className="flex items-center justify-between bg-slate-900/50 p-3 rounded-lg border border-slate-700/50 hover:border-indigo-500/30 transition-colors group cursor-pointer"
                  onClick={() => onSelectMatch(match.home, match.away, match.league)}
                >
                  <div className="flex flex-col">
                     <span className="text-xs text-slate-500 mb-0.5">{match.league} • {match.time}</span>
                     <span className="font-medium text-slate-200 group-hover:text-white">{match.home} <span className="text-slate-600 text-xs">vs</span> {match.away}</span>
                  </div>
                  <ArrowRight size={14} className="text-slate-600 group-hover:text-indigo-400 opacity-0 group-hover:opacity-100 transition-all" />
                </div>
              ))}
            </div>
          </div>

          {/* Accumulator Tip */}
          <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-4 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-16 h-16 bg-indigo-500 blur-3xl opacity-20"></div>
             <div className="flex items-center gap-2 mb-3">
                <Lightbulb className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-indigo-300">{t.dailyTip}</h3>
             </div>
             
             <div className="space-y-2 mb-4">
                {data.accumulator.games.map((game, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-sm">
                     <span className="text-indigo-500 mt-1">•</span>
                     <span className="text-slate-200">{game}</span>
                  </div>
                ))}
             </div>
             
             <div className="flex items-center justify-between text-sm border-t border-indigo-500/20 pt-3 mt-auto">
                <span className="text-slate-400">Odds:</span>
                <span className="font-mono font-bold text-indigo-400 bg-indigo-950 px-2 py-1 rounded">{data.accumulator.total_odds}</span>
             </div>
             <p className="text-xs text-slate-500 mt-2 italic leading-relaxed">
               "{data.accumulator.reasoning}"
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DailyInsightCard;
