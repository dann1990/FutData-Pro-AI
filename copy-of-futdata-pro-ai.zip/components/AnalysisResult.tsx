
import React from 'react';
import { AnalysisResult as AnalysisType } from '../types';
import ProbabilityChart from './ProbabilityChart';
import { ShieldCheck, TrendingUp, AlertTriangle, Goal, Activity, CheckCircle2, Clock, History } from 'lucide-react';

interface Props {
  data: AnalysisType;
  lang: 'en' | 'pt';
}

const LABELS = {
  en: {
    analysisComplete: "Analysis Complete",
    expectedGoals: "Expected Goals (xG)",
    powerRanking: "Power Ranking",
    attack: "Attack",
    defense: "Defense",
    keyMarkets: "Key Markets",
    winnerSafety: "Winner (Safety)",
    risk: "Risk",
    totalGoals: "Total Goals",
    total: "Total",
    finalVerdict: "Final Verdict",
    smartAccumulator: "Smart Accumulator",
    combinedOdds: "Combined Odds",
    h2hTitle: "Head to Head History"
  },
  pt: {
    analysisComplete: "Análise Completa",
    expectedGoals: "Gols Esperados (xG)",
    powerRanking: "Ranking de Força",
    attack: "Ataque",
    defense: "Defesa",
    keyMarkets: "Mercados Principais",
    winnerSafety: "Vencedor (Segurança)",
    risk: "Risco",
    totalGoals: "Total de Gols",
    total: "Total",
    finalVerdict: "Veredito Final",
    smartAccumulator: "Múltipla Inteligente",
    combinedOdds: "Odds Combinadas",
    h2hTitle: "Histórico de Confrontos"
  }
};

const StatBar: React.FC<{ label: string; value: number; colorClass: string }> = ({ label, value, colorClass }) => (
  <div className="mb-3">
    <div className="flex justify-between text-xs font-medium text-slate-400 mb-1">
      <span>{label}</span>
      <span>{value}/10</span>
    </div>
    <div className="w-full bg-slate-700 rounded-full h-2">
      <div
        className={`h-2 rounded-full ${colorClass}`}
        style={{ width: `${value * 10}%` }}
      ></div>
    </div>
  </div>
);

const AnalysisResult: React.FC<Props> = ({ data, lang }) => {
  const { match_info, stats, predictions, verdict, accumulator, h2h_history } = data;
  const t = LABELS[lang];

  // Color logic for risk
  const riskColor = verdict.risk_level <= 3 ? 'text-emerald-400' : verdict.risk_level <= 6 ? 'text-yellow-400' : 'text-red-400';
  const riskBg = verdict.risk_level <= 3 ? 'bg-emerald-500/10 border-emerald-500/30' : verdict.risk_level <= 6 ? 'bg-yellow-500/10 border-yellow-500/30' : 'bg-red-500/10 border-red-500/30';

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-fade-in">
      {/* Header Card */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-6 flex flex-col md:flex-row justify-between items-center text-center md:text-left shadow-lg">
        <div>
            <div className="text-xs font-mono text-emerald-400 mb-1 uppercase tracking-widest">{t.analysisComplete}</div>
            <h2 className="text-2xl font-bold text-white">{match_info.home} <span className="text-slate-500 text-lg">vs</span> {match_info.away}</h2>
            <div className="flex items-center justify-center md:justify-start gap-2 mt-2 text-slate-400 text-sm">
              <span className="bg-slate-700/50 px-2 py-0.5 rounded text-slate-300 border border-slate-600/50">{match_info.league}</span>
              <span>•</span>
              <span>{match_info.date}</span>
              <span>•</span>
              <span className="flex items-center gap-1 text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                <Clock size={12} /> {match_info.time}
              </span>
            </div>
        </div>
        <div className="mt-4 md:mt-0 flex flex-col items-center">
            <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">{t.expectedGoals}</div>
            <div className="text-3xl font-mono font-bold text-blue-400">{stats.xg_total}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Stats Column */}
        <div className="space-y-6">
           <div className="bg-slate-800 rounded-xl border border-slate-700 p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-4 border-b border-slate-700 pb-3">
                  <Activity className="w-5 h-5 text-indigo-400" />
                  <h3 className="text-lg font-semibold text-white">{t.powerRanking}</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-x-8">
                 <div>
                    <h4 className="text-sm font-bold text-slate-300 mb-3 text-center">{match_info.home}</h4>
                    <StatBar label={t.attack} value={stats.home_stats.attack} colorClass="bg-blue-500" />
                    <StatBar label={t.defense} value={stats.home_stats.defense} colorClass="bg-indigo-500" />
                 </div>
                 <div>
                    <h4 className="text-sm font-bold text-slate-300 mb-3 text-center">{match_info.away}</h4>
                    <StatBar label={t.attack} value={stats.away_stats.attack} colorClass="bg-orange-500" />
                    <StatBar label={t.defense} value={stats.away_stats.defense} colorClass="bg-red-500" />
                 </div>
              </div>
           </div>

           {/* H2H Section */}
           {h2h_history && h2h_history.length > 0 && (
             <div className="bg-slate-800 rounded-xl border border-slate-700 p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-4 border-b border-slate-700 pb-3">
                    <History className="w-5 h-5 text-slate-400" />
                    <h3 className="text-lg font-semibold text-white">{t.h2hTitle}</h3>
                </div>
                <div className="space-y-2">
                    {h2h_history.map((match, idx) => (
                        <div key={idx} className="flex justify-between items-center text-sm bg-slate-900/50 p-2 rounded border border-slate-700/30">
                            <div className="text-slate-400 text-xs">{match.date}</div>
                            <div className="flex-1 text-center font-medium text-slate-200">
                                <span className={match.home_team === match_info.home ? 'text-white' : 'text-slate-400'}>{match.home_team}</span>
                                <span className="mx-2 bg-slate-700 px-1.5 py-0.5 rounded text-xs">{match.score}</span>
                                <span className={match.away_team === match_info.away ? 'text-white' : 'text-slate-400'}>{match.away_team}</span>
                            </div>
                        </div>
                    ))}
                </div>
             </div>
           )}

           {/* Poisson Chart */}
           <ProbabilityChart probabilities={stats.probabilities} lang={lang} />
        </div>

        {/* Predictions Column */}
        <div className="space-y-6">
            {/* Markets */}
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-4 border-b border-slate-700 pb-3">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-lg font-semibold text-white">{t.keyMarkets}</h3>
                </div>
                
                <div className="space-y-4">
                    <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                            <div className="bg-emerald-500/20 p-2 rounded-md text-emerald-400"><ShieldCheck size={18}/></div>
                            <div>
                                <p className="text-xs text-slate-400 uppercase">{t.winnerSafety}</p>
                                <p className="font-bold text-white">{predictions.winner.selection}</p>
                            </div>
                        </div>
                        <span className="text-xs bg-slate-700 px-2 py-1 rounded text-slate-300">{predictions.winner.risk} {t.risk}</span>
                    </div>

                    <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                            <div className="bg-blue-500/20 p-2 rounded-md text-blue-400"><Goal size={18}/></div>
                            <div>
                                <p className="text-xs text-slate-400 uppercase">{t.totalGoals}</p>
                                <p className="font-bold text-white">{predictions.goals.selection}</p>
                            </div>
                        </div>
                        <span className="text-xs bg-slate-700 px-2 py-1 rounded text-slate-300">{predictions.goals.probability}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-2">
                        <div className="text-center bg-slate-900/30 p-2 rounded border border-slate-700/30">
                            <p className="text-xs text-slate-500">{match_info.home} {t.total}</p>
                            <p className="font-mono text-sm font-semibold text-slate-200">{predictions.home_total}</p>
                        </div>
                        <div className="text-center bg-slate-900/30 p-2 rounded border border-slate-700/30">
                            <p className="text-xs text-slate-500">{match_info.away} {t.total}</p>
                            <p className="font-mono text-sm font-semibold text-slate-200">{predictions.away_total}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Verdict */}
            <div className={`rounded-xl border p-5 shadow-sm ${riskBg}`}>
                 <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                        <CheckCircle2 className={`w-5 h-5 ${riskColor}`} />
                        <h3 className={`text-lg font-bold ${riskColor}`}>{t.finalVerdict}</h3>
                    </div>
                    <span className={`text-xs font-bold px-2 py-1 rounded bg-slate-900/40 ${riskColor}`}>{t.risk}: {verdict.risk_level}/10</span>
                 </div>
                 <p className="text-xl font-bold text-white mb-2">{verdict.safest_bet}</p>
                 <p className="text-sm text-slate-300 leading-relaxed italic">"{verdict.justification}"</p>
            </div>
        </div>
      </div>

      {/* Accumulator Bonus */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-xl border border-purple-500/30 p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-purple-500 blur-3xl opacity-20"></div>
          <div className="relative z-10">
             <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-purple-400" />
                <h4 className="text-sm font-bold text-purple-400 uppercase tracking-wider">{t.smartAccumulator}</h4>
             </div>
             <p className="text-white font-medium mb-1">{accumulator.suggestion}</p>
             <p className="text-sm text-slate-400">{t.combinedOdds}: <span className="text-purple-400 font-mono font-bold">{accumulator.odds_range}</span></p>
          </div>
      </div>
    </div>
  );
};

export default AnalysisResult;
